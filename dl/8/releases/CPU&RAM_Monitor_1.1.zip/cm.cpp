#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <signal.h> //����Ctrl-C�¼�Ҫ�õ�
#include <unistd.h> //ʹ��sleep();Ҫ�õ�

#define REC_FREQ 15 //ÿn���¼һ��
#define ERR_FAILED_TO_OPEN_LOG_FILE -1
#define BUILDTIME "151002.211649"
#define VERSION "1.1"

using namespace std;

string GetHardwareInfo(); //��ȡӲ����Ϣ������Ϊһ������string

volatile sig_atomic_t flag = 0;

static void my_handler(int sig){ // ���Ա��첽����
  flag = 1;
}

int main(){
    cout << "Welcome to use Cpu&Ram Monitor!\nAuthor: Keuin   BuildTime: " << BUILDTIME << "  Version: "<< VERSION<< endl;
    signal(SIGINT, my_handler);
    cout << "Opening log file: HardwareLog.txt" <<endl;
    ofstream log("HardwareLog.txt");
    if(!log.good()){ //����־�ļ�
        cout<<"Failed to open file: HardwareLog.txt !"<<endl;
        return ERR_FAILED_TO_OPEN_LOG_FILE;
    }
    cout << "Done! Now record." <<endl;
    
    int count = 0; //���������ǹ�REC_FREQ����¼һ�Ρ�
    while(flag != 1){
        ++count;
        if(count == REC_FREQ){
            count = 0; //��������λ
            log << GetHardwareInfo()
                << "\n";
            cout << "Log saved." <<endl;
        }
        sleep(1); //sleep һ��
    }
    
    cout << "Closing log file...";
    log.close();
    return 0;
}

string GetHardwareInfo(){
    ifstream f; //�ļ���
    string infOut; //������
    vector<string> inf_; //�Ի��з��ָ����Ϣ
    string inf;
    string ln;
    
    f.open("/proc/stat");
    while(getline(f,ln))
        inf_.push_back(ln);
    f.close();
    
    for(string l : inf_){
        if(l.substr(0,3) == "cpu"){
            inf+=l;
            inf+=" ";
        }else{
            infOut+=inf;
            infOut+=" ";
            break;
        }
    }
    
    inf_.clear(); //�����vector
    inf.clear();
    
    f.open("/proc/meminfo");
    while(getline(f,ln))
        inf_.push_back(ln);
    f.close();
    
    for(string l : inf_){
        if(l.substr(0,8) == "MemTotal"){
            auto endp = l.rfind(" "); //���ҽ�β�ո�
            auto begp = l.substr(0,endp).rfind(" "); //���ҿ�ʼ�ո�
            inf+=l.substr(begp,endp - begp + 1);
            inf+=" ";
        }else 
        if(l.substr(0,7) == "MemFree"){
            auto endp = l.rfind(" "); //���ҽ�β�ո�
            auto begp = l.substr(0,endp).rfind(" "); //���ҿ�ʼ�ո�
            inf+=l.substr(begp,endp - begp + 1);
            inf+=" ";
            infOut+=inf;
            break;
        }
    }
    
    return infOut;
}